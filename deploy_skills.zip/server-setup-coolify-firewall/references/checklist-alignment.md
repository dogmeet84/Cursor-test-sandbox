# Checklist alignment with $check-coolify

Use this file as a compact bridge between server bootstrap and repo readiness checks.

## Must match from server baseline

1. Security baseline completed:
- `apt-get full-upgrade` applied.
- `fail2ban` active (`sshd` jail enabled).
- `unattended-upgrades` enabled.
- SSH hardened (`PermitRootLogin` restricted, password auth disabled only when key auth is present).
- UFW enabled: incoming deny, outgoing allow, `OpenSSH` plus `80/tcp` and `443/tcp` always allowed.

2. Server env path:
- `/opt/configs/${PROJECT_NAME}/${ENV_TYPE}.env`

3. Coolify restart rule:
- After editing env file on VPS, trigger Restart in Coolify.

4. Compose requirements:
- `env_file` points to `/opt/configs/...` path.
- Do not set `traefik.http.routers.*.tls.certresolver` inside compose.
- Enable log rotation (`json-file`, `max-size`, `max-file`) for all services.
- Add resource limits (at least RAM for main app service).
- Use external `coolify` network and internal bridge where appropriate.

5. Local override requirement:
- Local `docker-compose.override.yml` should avoid requiring external `coolify` network.

## Suggested verification commands

```bash
# On VPS
systemctl is-active fail2ban
systemctl is-enabled unattended-upgrades
sshd -t
ufw status verbose
ls -l /opt/configs/${PROJECT_NAME}/${ENV_TYPE}.env

# In repo (local)
# Run $check-coolify and collect PASS/FAIL report
```
