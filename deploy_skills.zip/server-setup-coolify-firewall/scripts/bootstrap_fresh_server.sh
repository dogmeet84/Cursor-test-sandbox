#!/usr/bin/env bash
set -euo pipefail

SWAP_MODE="auto"                 # auto | force | off
SWAP_GB=2
MAX_RAM_GB_FOR_SWAP=2
ENABLE_FTP=0

usage() {
  cat <<'EOF'
Usage: bootstrap_fresh_server.sh [options]

Options:
  --swap-mode=auto|force|off
      auto:  create swap only when no swap exists and RAM <= threshold
      force: create swap when no swap exists (ignore RAM threshold)
      off:   skip swap setup
  --swap-gb=N
      swap size in GiB when creating swap (default: 2)
  --max-ram-gb-for-swap=N
      RAM threshold for --swap-mode=auto (default: 2)
  --enable-ftp
      open TCP 21 in UFW
  --help
      show this help
EOF
}

while (($#)); do
  case "$1" in
    --swap-mode=*)
      SWAP_MODE="${1#*=}"
      ;;
    --swap-gb=*)
      SWAP_GB="${1#*=}"
      ;;
    --max-ram-gb-for-swap=*)
      MAX_RAM_GB_FOR_SWAP="${1#*=}"
      ;;
    --enable-ftp)
      ENABLE_FTP=1
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
  shift
done

if [[ ! "$SWAP_MODE" =~ ^(auto|force|off)$ ]]; then
  echo "Invalid --swap-mode value: $SWAP_MODE" >&2
  exit 1
fi

if [[ ! "$SWAP_GB" =~ ^[1-9][0-9]*$ ]]; then
  echo "Invalid --swap-gb value: $SWAP_GB" >&2
  exit 1
fi

if [[ ! "$MAX_RAM_GB_FOR_SWAP" =~ ^[1-9][0-9]*$ ]]; then
  echo "Invalid --max-ram-gb-for-swap value: $MAX_RAM_GB_FOR_SWAP" >&2
  exit 1
fi

SUDO=""
if [[ "$(id -u)" -ne 0 ]]; then
  SUDO="sudo"
fi

set_sshd_opt() {
  local key="$1"
  local value="$2"
  local sshd_cfg="$3"
  if $SUDO grep -qiE "^[[:space:]]*#?[[:space:]]*${key}[[:space:]]+" "$sshd_cfg"; then
    $SUDO sed -ri "s|^[[:space:]]*#?[[:space:]]*${key}[[:space:]].*|${key} ${value}|I" "$sshd_cfg"
  else
    echo "${key} ${value}" | $SUDO tee -a "$sshd_cfg" >/dev/null
  fi
}

configure_swap() {
  local swap_file="/swapfile"
  local swap_mb=$((SWAP_GB * 1024))
  if [[ -f "$swap_file" ]]; then
    echo "Swap file $swap_file already exists, skipping creation."
  else
    echo "Creating ${SWAP_GB}GiB swap file."
    ($SUDO fallocate -l "${SWAP_GB}G" "$swap_file") || \
      ($SUDO dd if=/dev/zero of="$swap_file" bs=1M count="$swap_mb" status=progress)
    $SUDO chmod 600 "$swap_file"
    $SUDO mkswap "$swap_file" >/dev/null
  fi

  if ! swapon --noheadings --show | grep -q .; then
    $SUDO swapon "$swap_file"
  fi
  if ! $SUDO grep -qE "^${swap_file}[[:space:]]" /etc/fstab; then
    echo "${swap_file} none swap sw 0 0" | $SUDO tee -a /etc/fstab >/dev/null
  fi

  echo "vm.swappiness=10" | $SUDO tee /etc/sysctl.d/99-swappiness.conf >/dev/null
  $SUDO sysctl -p /etc/sysctl.d/99-swappiness.conf >/dev/null || true
}

echo "== APT: update + full-upgrade =="
$SUDO apt-get update -y
DEBIAN_FRONTEND=noninteractive $SUDO apt-get -y full-upgrade

echo "== Install baseline packages =="
DEBIAN_FRONTEND=noninteractive $SUDO apt-get -y install \
  ca-certificates curl fail2ban unattended-upgrades ufw

echo "== fail2ban: enable + sshd jail =="
$SUDO systemctl enable --now fail2ban
cat <<'EOF' | $SUDO tee /etc/fail2ban/jail.d/sshd.local >/dev/null
[sshd]
enabled = true
maxretry = 5
findtime = 10m
bantime = 1h
EOF
$SUDO systemctl restart fail2ban

echo "== unattended-upgrades: enable security updates =="
cat <<'EOF' | $SUDO tee /etc/apt/apt.conf.d/20auto-upgrades >/dev/null
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
EOF
cat <<'EOF' | $SUDO tee /etc/apt/apt.conf.d/52unattended-upgrades-local >/dev/null
Unattended-Upgrade::Remove-Unused-Dependencies "true";
Unattended-Upgrade::Automatic-Reboot "false";
EOF
$SUDO systemctl enable --now unattended-upgrades || true

echo "== SSH hardening =="
SSHD_CFG="/etc/ssh/sshd_config"
LOGIN_USER="${SUDO_USER:-$(id -un)}"
HOME_U="$(getent passwd "$LOGIN_USER" | cut -d: -f6 || true)"
if [[ -z "$HOME_U" ]]; then
  HOME_U="$HOME"
fi
AUTH_KEYS="${HOME_U}/.ssh/authorized_keys"

if [[ "$LOGIN_USER" == "root" ]]; then
  set_sshd_opt PermitRootLogin "prohibit-password" "$SSHD_CFG"
else
  set_sshd_opt PermitRootLogin "no" "$SSHD_CFG"
fi

if [[ -s "$AUTH_KEYS" ]]; then
  set_sshd_opt PasswordAuthentication "no" "$SSHD_CFG"
  set_sshd_opt KbdInteractiveAuthentication "no" "$SSHD_CFG"
else
  echo "WARN: ${AUTH_KEYS} not found/empty, keep password auth to avoid lockout."
fi

$SUDO sshd -t
$SUDO systemctl reload ssh || $SUDO systemctl reload sshd

echo "== UFW baseline =="
$SUDO ufw --force reset
$SUDO ufw default deny incoming
$SUDO ufw default allow outgoing
$SUDO ufw allow OpenSSH >/dev/null || true
$SUDO ufw allow 80/tcp >/dev/null || true
$SUDO ufw allow 443/tcp >/dev/null || true

if [[ "$ENABLE_FTP" == "1" ]]; then
  $SUDO ufw allow 21/tcp comment 'FTP control' >/dev/null || true
fi

$SUDO ufw --force enable
$SUDO ufw reload >/dev/null || true

echo "== Swap setup =="
if swapon --noheadings --show | grep -q .; then
  echo "Swap already present, skip."
elif [[ "$SWAP_MODE" == "off" ]]; then
  echo "Swap setup is disabled."
elif [[ "$SWAP_MODE" == "force" ]]; then
  configure_swap
else
  MEM_KB="$(awk '/MemTotal/{print $2}' /proc/meminfo)"
  MAX_RAM_KB=$((MAX_RAM_GB_FOR_SWAP * 1024 * 1024))
  if (( MEM_KB <= MAX_RAM_KB )); then
    configure_swap
  else
    echo "Skip swap: RAM is above ${MAX_RAM_GB_FOR_SWAP}GiB threshold."
  fi
fi

echo "== DONE =="
$SUDO fail2ban-client status sshd || true
$SUDO ufw status verbose || true
swapon --show || true
if [[ -f /var/run/reboot-required ]]; then
  echo "NOTICE: reboot required (/var/run/reboot-required)."
fi
