---
name: server-setup-coolify-firewall
description: "Provision a fresh VPS for Coolify with baseline hardening (updates, fail2ban, unattended-upgrades, SSH/UFW/swap), then align repo/server setup with check-coolify requirements."
---

# Server setup: secure baseline + Coolify

## Purpose

Prepare a clean VPS for Coolify deployment with baseline security, automatic updates, and configuration layout compatible with `$check-coolify`.

## Inputs

- SSH credentials from env (`SERVER_ADDRESS`, `SSH_KEY`, optional `SSH_USER`, `SSH_PORT`).
- Deployment variables (at minimum): `PROJECT_NAME`, `ENV_TYPE`, `DOMAIN`.
- Whether FTP is required (`--enable-ftp` only if needed).

## Workflow

1. Connect to server using `$ssh-connect-env`.
2. Apply baseline hardening script from this skill (updates + fail2ban + unattended-upgrades + SSH/UFW/swap).
3. Reboot if required and reconnect.
4. Install Coolify.
5. Prepare server-side env file layout in `/opt/configs`.
6. Validate repo readiness by running `$check-coolify` and fixing FAIL items before deploy.

## 1) Connect using env credentials

```bash
eval "$(/Users/glebk/.codex/skills/ssh-connect-env/scripts/resolve_ssh_env.sh --export)"
ssh -i "$SSH_KEY_PATH" -p "$SSH_PORT" -o StrictHostKeyChecking=accept-new "$SSH_TARGET"
```

## 2) Apply security baseline (single command from local machine)

Run this from local machine after `resolve_ssh_env.sh`:

```bash
ssh -i "$SSH_KEY_PATH" -p "$SSH_PORT" -o StrictHostKeyChecking=accept-new "$SSH_TARGET" \
  'bash -s -- --swap-mode=auto' \
  < /Users/glebk/.codex/skills/server-setup-coolify-firewall/scripts/bootstrap_fresh_server.sh
```

Script behavior (idempotent where practical):

- `apt-get update` + `full-upgrade`
- install/enable `fail2ban`, `unattended-upgrades`, `ufw`
- configure fail2ban jail for SSH
- set unattended updates policy
- harden SSH:
  - `PermitRootLogin no` (or `prohibit-password` when current login user is `root`)
  - disable password auth only if `authorized_keys` exists (lockout-safe)
- UFW:
  - deny incoming by default, allow outgoing
  - always allow `OpenSSH` (`22/tcp`)
  - always allow `80/tcp` and `443/tcp`
  - open `21` only with `--enable-ftp`
- create swap only when needed by policy (`--swap-mode`)

Useful flags:

- enable FTP control port 21: add `--enable-ftp`
- force swap creation (if no swap): `--swap-mode=force --swap-gb=2`

## 3) Reboot if required

If baseline script reports reboot requirement, reboot and reconnect before installing Coolify.

```bash
sudo reboot
```

## 4) Install Coolify

Run on the server as root:

```bash
curl -fsSL https://cdn.coollabs.io/coolify/install.sh | bash
```

Post-install checks:

```bash
docker --version
docker ps
```

If installer URL changes, fetch the current command from official Coolify docs and re-run.

## 5) Prepare server env layout

Run on the server:

```bash
export PROJECT_NAME=vibeportal
export ENV_TYPE=prod
mkdir -p "/opt/configs/${PROJECT_NAME}"
touch "/opt/configs/${PROJECT_NAME}/${ENV_TYPE}.env"
chmod 600 "/opt/configs/${PROJECT_NAME}/${ENV_TYPE}.env"
```

Important behavior from `$check-coolify` checklist:

- Runtime env must be read from `/opt/configs/${PROJECT_NAME}/${ENV_TYPE}.env`.
- After editing this file (e.g. via SFTP), restart app in Coolify to apply new variables.

## 6) Align with check-coolify before deploy

In repo workspace, run readiness audit with `$check-coolify` and fix all high-impact FAIL items.

Use `references/checklist-alignment.md` from this skill for mandatory alignment points and command snippets.

## Done criteria

- Baseline hardening script completed without SSH lockout.
- `fail2ban` active with `sshd` jail.
- `unattended-upgrades` enabled.
- SSH hardened per script policy.
- UFW active with allow-list containing `OpenSSH`, `80/tcp`, `443/tcp` (plus optional `21/tcp` only when needed).
- Swap configured by chosen policy.
- Coolify installed and running.
- `/opt/configs/${PROJECT_NAME}/${ENV_TYPE}.env` exists with proper permissions.
- Repo passes `$check-coolify` (or has explicit accepted exceptions).
