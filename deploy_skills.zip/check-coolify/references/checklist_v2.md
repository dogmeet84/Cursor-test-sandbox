# Улучшенный Чек-лист (Версия 2.0) — Coolify готовность

Ниже — чек-лист-источник истины для `docker-compose`-деплоя в Coolify с GitOps-подходом и минимизацией кликов в UI.

## 1. Структура на VPS

- Путь: `/opt/configs/${PROJECT_NAME}/${ENV_TYPE}.env`
- Важно: после изменения файла через SFTP нужно нажать **Restart** в Coolify, чтобы контейнер пересоздался с новыми переменными.

## 2. Структура репозитория

- `docker-compose.yml` (Prod/Stage)
- `docker-compose.override.yml` (Local, в `.gitignore`)
- `scripts/validate_env.sh` (скрипт валидации)
- `.env.example` (шаблон переменных для разработчиков)

## 3. `docker-compose.yml` (Prod & Stage) — требования и пример

Изменения/принципы:

- Добавить ротацию логов (json-file max-size/max-file), чтобы не забить диск VPS.
- Добавить лимиты ресурсов (минимум RAM), чтобы один контейнер не положил весь VPS.
- Убрать конфликтующие SSL-лейблы Traefik (не задавать `tls.certresolver`), оставить только роутинг.
- Улучшить healthcheck Mongo (mongosh ping + start_period).

Пример:

```yaml
version: '3.8'

# Глобальные настройки логирования для всех сервисов (чтобы не забить диск VPS)
x-logging: &default-logging
  driver: "json-file"
  options:
    max-size: "10m"
    max-file: "3"

services:
  app:
    build: .
    restart: unless-stopped
    logging: *default-logging
    # Ограничение ресурсов (защита от падения всего VPS)
    deploy:
      resources:
        limits:
          memory: 512M
    env_file:
      - /opt/configs/${PROJECT_NAME}/${ENV_TYPE}.env
    environment:
      - DB_HOST=db
      - NODE_ENV=${ENV_TYPE}
    entrypoint: ["/app/scripts/validate_env.sh"]
    command: ["npm", "start"]
    depends_on:
      db:
        condition: service_healthy
    networks:
      - coolify
      - internal
    labels:
      - "traefik.enable=true"
      # Роутинг: app.com (frontend) или app.com/api (backend)
      - "traefik.http.routers.${PROJECT_NAME}-${ENV_TYPE}-app.rule=Host(`${DOMAIN}`) && PathPrefix(`/api`)"
      # Убрали label с certresolver, Coolify сам повесит SSL на Host(`${DOMAIN}`)

  db:
    image: mongo:6.0
    restart: unless-stopped
    logging: *default-logging
    env_file:
      - /opt/configs/${PROJECT_NAME}/${ENV_TYPE}.env
    volumes:
      - db_data:/data/db
    networks:
      - internal
    # Улучшенный healthcheck для Mongo 6+
    healthcheck:
      test: ["CMD", "mongosh", "--eval", "db.adminCommand('ping')"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 10s # Даем время на инициализацию при первом запуске

volumes:
  db_data:

networks:
  coolify:
    external: true
  internal:
    driver: bridge
```

## 4. `docker-compose.override.yml` (Локальная разработка) — требования и пример

Цель: локально Docker не должен ругаться на отсутствие внешней сети `coolify`.

```yaml
version: '3.8'

services:
  app:
    env_file:
      - .env
    ports:
      - "3000:3000"
    environment:
      - DOMAIN=localhost
      - ENV_TYPE=local
      - PROJECT_NAME=myproject

  db:
    env_file:
      - .env
    ports:
      - "27017:27017"

# Заглушка для сети, чтобы локально Docker не искал внешнюю сеть Coolify
networks:
  coolify:
    external: false
    driver: bridge
```

## 5. `scripts/validate_env.sh` — требования и пример

Цель: скрипт должен показывать список **всех** отсутствующих переменных за один запуск, а не падать на первой.

```bash
#!/bin/sh

echo \"--> Validating Environment Variables...\"

REQUIRED_VARS=\"DOMAIN DB_HOST DB_NAME\"
MISSING_VARS=0

for var in $REQUIRED_VARS; do
  if [ -z \"$(eval echo \\$$var)\" ]; then
    echo \"❌ ERROR: Required variable $var is missing!\"
    MISSING_VARS=1
  fi
done

if [ $MISSING_VARS -eq 1 ]; then
  echo \"💥 Deployment aborted due to missing environment variables.\"
  exit 1
fi

echo \"✅ Environment OK.\"
exec \"$@\"
```

## 6. Резюме по процессу деплоя (Workflow)

1. Один раз: создать папки и файлы `.env` на сервере (`/opt/configs/...`).
2. В UI Coolify: создать проект и указать 3 переменные:
   - `PROJECT_NAME` (например: `crm`)
   - `ENV_TYPE` (`prod` или `stage`)
   - `DOMAIN` (`crm.com` или `stage.crm.com`)
3. Нажать Deploy: Coolify берет код из Git, подставляет 3 переменные в `docker-compose.yml`, тот читает конфиг с сервера, Traefik читает лейблы и настраивает роутинг и SSL.

