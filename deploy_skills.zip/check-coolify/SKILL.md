---
name: check-coolify
description: "Checklist and readiness review for deploying a repo to Coolify with a GitOps-friendly docker-compose setup: server-side env files in /opt/configs, Traefik routing labels (without tls certresolver conflicts), log rotation, basic resource limits, local docker-compose.override.yml network stub, and env validation script. Use when asked to check/score Coolify deployment readiness and propose fixes (keywords: Coolify, кулифай, check_coolify)."
---

# Check Coolify readiness (Checklist v2.0)

## Purpose

Review a repository for deployment readiness in Coolify using the agreed GitOps approach:

- Keep project env files on the VPS at `/opt/configs/${PROJECT_NAME}/${ENV_TYPE}.env`.
- Keep `docker-compose.yml` in Git (prod/stage).
- Keep local-only `docker-compose.override.yml` out of Git (in `.gitignore`), but validate that local dev can run without Coolify's external network.

### Local env naming convention

Many repos keep *one active* `.env` (used by `docker compose`) and store per-environment copies locally as:

- `.env.local`, `.env.stage`, `.env.prod` (not committed)
- optional templates: `.env.local.example`, `.env.stage.example`, `.env.prod.example` (committed)

If such convention exists, ensure docs/Makefile explain how `.env` is generated/symlinked from `.env.<env>`.

## Workflow

1. Identify relevant files in the repo:
   - `docker-compose.yml`
   - `.env.example` (or `.env.<env>.example` templates)
   - `.env.*` naming rules in `.gitignore`
   - `scripts/validate_env.sh`
   - `.gitignore`
   - `docker-compose.override.yml` (may be absent if gitignored; check if there is an example or docs)
   - `Makefile` / scripts that switch `.env` (optional)
   - any deployment docs (README, docs/)
2. Compare the repo against Checklist v2.0.
   - Use `references/checklist_v2.md` as the source of truth for required patterns and example snippets.
3. Produce a report (do not change files unless the user explicitly asks to fix).

## What to check (high level)

### VPS env strategy

- `docker-compose.yml` uses `env_file: /opt/configs/${PROJECT_NAME}/${ENV_TYPE}.env`.
- There is an explicit note (docs or report) that after editing that env file on the server you must press **Restart** in Coolify to apply changes.

### Local env strategy

If the repo uses `.env.<env>` (e.g. `.env.local`, `.env.stage`, `.env.prod`):

- The repo has a clear way to select an environment for local dev (Makefile/script) that results in a valid `.env` file in the repo root.
- `.gitignore` ignores secrets:
  - `.env`, `.env.*` (except `.env.example` and/or `.env.*.example` templates)
- Local docs explain what to edit and which file is *the* active one for `docker compose`.

### Repo structure

- `.env.example` exists (or a documented equivalent like `.env.local.example`) and matches required runtime vars.
- `scripts/validate_env.sh` exists and is referenced as the app entrypoint (or otherwise guaranteed to run before start).
- `.gitignore` ignores `docker-compose.override.yml` (or repo documents why not).

### `docker-compose.yml` (prod/stage)

- No Traefik SSL resolver conflict: do not set `traefik.http.routers.*.tls.certresolver=...` inside the compose file; let Coolify manage SSL.
- Log rotation configured for all services (json-file with `max-size` and `max-file`).
- Basic resource limits defined (at least memory for the main app service).
- Network setup:
  - `coolify` network is `external: true`
  - services attach to `coolify` and an `internal` bridge network when appropriate
- DB service (Mongo in the reference example):
  - persistent volume configured
  - healthcheck uses `mongosh` ping and has `start_period`

### Local override

- If `docker-compose.override.yml` exists locally or as an example, it overrides the `coolify` network with `external: false` so local Docker does not require the Coolify network.
- If local env switching is used (`.env.<env>`), the override should still reference only `.env` so developers don't need to edit compose files per environment.

## Output format (report)

Return:

- `Score: X/10` (or `X/Y` if some checks are N/A), plus a one-line readiness verdict.
- A checklist table with: **Check**, **Status (PASS/FAIL/N/A)**, **Evidence (file + line)**, **Fix**.
- A short “Top risks” section with the 1–3 highest-impact fails.

When suggesting fixes, prefer minimal diffs aligned with Checklist v2.0, and call out any assumptions.
