#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage:
  resolve_ssh_env.sh [--env-file <path>] [--export]

Options:
  --env-file <path>  Path to env file. If omitted, auto-detect in this order:
                     .env, .env.local, .env.prod, .env.stage
  --export           Print shell export statements instead of plain key=value output
  -h, --help         Show help
USAGE
}

trim() {
  local value="$1"
  value="${value#"${value%%[![:space:]]*}"}"
  value="${value%"${value##*[![:space:]]}"}"
  printf '%s' "$value"
}

unquote() {
  local value="$1"
  if [[ ${#value} -ge 2 ]]; then
    if [[ "$value" == \"*\" && "$value" == *\" ]]; then
      value="${value:1:${#value}-2}"
    elif [[ "$value" == \'*\' && "$value" == *\' ]]; then
      value="${value:1:${#value}-2}"
    fi
  fi
  printf '%s' "$value"
}

read_var() {
  local env_file="$1"
  local key="$2"
  local raw
  raw="$(awk -F= -v key="$key" '
    $1 ~ "^[[:space:]]*" key "[[:space:]]*$" {
      value=$0
      sub(/^[^=]*=/, "", value)
      print value
    }
  ' "$env_file" | tail -n1)"
  raw="${raw%$'\r'}"
  raw="$(trim "$raw")"
  raw="$(unquote "$raw")"
  printf '%s' "$raw"
}

expand_tilde() {
  local path="$1"
  if [[ "$path" == ~* ]]; then
    printf '%s' "${path/#\~/$HOME}"
  else
    printf '%s' "$path"
  fi
}

resolve_key_path() {
  local key_ref="$1"
  local candidate
  local -a candidates=()

  if [[ -n "$key_ref" ]]; then
    candidates+=("$(expand_tilde "$key_ref")")
    if [[ "$key_ref" != /* && "$key_ref" != ~* ]]; then
      candidates+=("$PWD/$key_ref")
    fi
    candidates+=("$HOME/.ssh/$key_ref")
    if [[ "$key_ref" != *.pem ]]; then
      candidates+=("$HOME/.ssh/$key_ref.pem")
    fi
  fi

  for candidate in "${candidates[@]}"; do
    if [[ -f "$candidate" ]]; then
      printf '%s' "$candidate"
      return 0
    fi
  done

  return 1
}

print_plain() {
  printf 'ENV_FILE=%s\n' "$ENV_FILE"
  printf 'SERVER_ADDRESS=%s\n' "$SERVER_ADDRESS"
  printf 'SSH_USER=%s\n' "$SSH_USER"
  printf 'SSH_PORT=%s\n' "$SSH_PORT"
  printf 'SSH_KEY_PATH=%s\n' "$SSH_KEY_PATH"
  printf 'SSH_TARGET=%s\n' "$SSH_TARGET"
}

print_exports() {
  printf 'export ENV_FILE=%q\n' "$ENV_FILE"
  printf 'export SERVER_ADDRESS=%q\n' "$SERVER_ADDRESS"
  printf 'export SSH_USER=%q\n' "$SSH_USER"
  printf 'export SSH_PORT=%q\n' "$SSH_PORT"
  printf 'export SSH_KEY_PATH=%q\n' "$SSH_KEY_PATH"
  printf 'export SSH_TARGET=%q\n' "$SSH_TARGET"
}

ENV_FILE=""
OUTPUT_MODE="plain"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --env-file)
      [[ $# -ge 2 ]] || { echo "--env-file requires a value" >&2; exit 2; }
      ENV_FILE="$2"
      shift 2
      ;;
    --export)
      OUTPUT_MODE="export"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

if [[ -z "$ENV_FILE" ]]; then
  for candidate in .env .env.local .env.prod .env.stage; do
    if [[ -f "$candidate" ]]; then
      ENV_FILE="$candidate"
      break
    fi
  done
fi

if [[ -z "$ENV_FILE" || ! -f "$ENV_FILE" ]]; then
  echo "Env file not found. Pass --env-file or create one of: .env .env.local .env.prod .env.stage" >&2
  exit 1
fi

SERVER_ADDRESS="$(read_var "$ENV_FILE" "SERVER_ADDRESS")"
SSH_KEY_REF="$(read_var "$ENV_FILE" "SSH_KEY")"
SSH_USER="$(read_var "$ENV_FILE" "SSH_USER")"
SSH_PORT="$(read_var "$ENV_FILE" "SSH_PORT")"

if [[ -z "$SSH_USER" ]]; then
  SSH_USER="$(read_var "$ENV_FILE" "SERVER_USER")"
fi

if [[ -z "$SSH_USER" ]]; then
  SSH_USER="root"
fi

if [[ -z "$SSH_PORT" ]]; then
  SSH_PORT="22"
fi

if [[ -z "$SERVER_ADDRESS" ]]; then
  echo "SERVER_ADDRESS is missing in $ENV_FILE" >&2
  exit 1
fi

if [[ -z "$SSH_KEY_REF" ]]; then
  echo "SSH_KEY is missing in $ENV_FILE" >&2
  exit 1
fi

if ! SSH_KEY_PATH="$(resolve_key_path "$SSH_KEY_REF")"; then
  echo "Cannot resolve SSH key path from SSH_KEY='$SSH_KEY_REF'" >&2
  echo "Checked raw path, cwd-relative path, and ~/.ssh variants" >&2
  exit 1
fi

SSH_TARGET="${SSH_USER}@${SERVER_ADDRESS}"

if [[ "$OUTPUT_MODE" == "export" ]]; then
  print_exports
else
  print_plain
fi
