---
name: ssh-connect-env
description: "Connect to VPS over SSH/SCP/SFTP by reading credentials from project .env files (SERVER_ADDRESS, SSH_KEY, optional SSH_USER/SSH_PORT). Use when asked to connect to a server, run remote commands, or transfer files using deploy creds stored in .env/.env.local/.env.prod/.env.stage."
---

# SSH connect from .env

## Purpose

Use this skill to build SSH connection parameters from local `.env*` files and connect without manually copying host/key values.

## Workflow

1. Resolve credentials from env file.
2. Validate the key path and target host.
3. Run SSH command (or SCP/SFTP) with the resolved values.

## 1) Resolve credentials

Run:

```bash
/Users/glebk/.codex/skills/ssh-connect-env/scripts/resolve_ssh_env.sh --export
```

Default env search order:

- `.env`
- `.env.local`
- `.env.prod`
- `.env.stage`

To force a file:

```bash
/Users/glebk/.codex/skills/ssh-connect-env/scripts/resolve_ssh_env.sh --env-file .env.local --export
```

Expected variables in env file:

- `SERVER_ADDRESS` (required)
- `SSH_KEY` (required)
- `SSH_USER` (optional, default: `root`)
- `SSH_PORT` (optional, default: `22`)

Fallback alias also supported:

- `SERVER_USER` for SSH user.

## 2) Connect / execute

Load exports and connect:

```bash
eval "$(/Users/glebk/.codex/skills/ssh-connect-env/scripts/resolve_ssh_env.sh --export)"
ssh -i "$SSH_KEY_PATH" -p "$SSH_PORT" -o StrictHostKeyChecking=accept-new "$SSH_TARGET"
```

Run remote command:

```bash
eval "$(/Users/glebk/.codex/skills/ssh-connect-env/scripts/resolve_ssh_env.sh --export)"
ssh -i "$SSH_KEY_PATH" -p "$SSH_PORT" -o StrictHostKeyChecking=accept-new "$SSH_TARGET" 'hostname && id -un'
```

SCP/SFTP:

```bash
eval "$(/Users/glebk/.codex/skills/ssh-connect-env/scripts/resolve_ssh_env.sh --export)"
scp -i "$SSH_KEY_PATH" -P "$SSH_PORT" ./local.file "$SSH_TARGET:/tmp/"
sftp -i "$SSH_KEY_PATH" -P "$SSH_PORT" "$SSH_TARGET"
```

## Safety

- Do not enable firewall rules before confirming SSH access works with the resolved key.
- Keep `StrictHostKeyChecking=accept-new` for first connect, then rely on `known_hosts` pinning.
- If sandbox blocks outbound SSH, rerun command with escalation.
